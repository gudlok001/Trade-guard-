import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "TradeGuard — Trade your plan, not your emotions",
  description: "Trading psychology and discipline journal for forex traders."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}