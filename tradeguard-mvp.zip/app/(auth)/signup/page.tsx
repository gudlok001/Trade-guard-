 "use client";
import { FormEvent, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase-browser";
import { useRouter } from "next/navigation";

export default function Signup() {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState(""); const [loading,setLoading]=useState(false); const router=useRouter();
  async function submit(e:FormEvent){e.preventDefault();setLoading(true);setError("");const {error}=await createClient().auth.signUp({email,password});if(error)setError(error.message);else router.push("/onboarding");setLoading(false);}
  return <main className="flex min-h-screen items-center justify-center p-5"><form onSubmit={submit} className="card w-full max-w-md p-7"><Link href="/" className="text-sm text-white/40">← TradeGuard</Link><h1 className="mt-8 text-3xl font-black">Create your account</h1><p className="mt-2 text-sm text-white/40">Build a trading process you can actually follow.</p><label className="mt-8 block text-sm">Email<input className="input mt-2" type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></label><label className="mt-4 block text-sm">Password<input className="input mt-2" type="password" minLength={6} value={password} onChange={e=>setPassword(e.target.value)} required/></label>{error&&<p className="mt-4 text-sm text-red-300">{error}</p>}<button disabled={loading} className="btn-primary mt-6 w-full">{loading?"Creating...":"Create account"}</button><p className="mt-5 text-center text-sm text-white/40">Already have an account? <Link className="text-white underline" href="/login">Log in</Link></p></form></main>
}