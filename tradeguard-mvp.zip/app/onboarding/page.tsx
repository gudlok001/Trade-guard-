 "use client";
import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase-browser";
import { useRouter } from "next/navigation";

export default function Onboarding(){
 const [form,setForm]=useState({maxTrades:3,maxLoss:2,risk:1,maxLosses:2,session:"London/New York",rules:""}); const [loading,setLoading]=useState(false); const router=useRouter();
 async function submit(e:FormEvent){e.preventDefault();setLoading(true);const c=createClient();const {data:{user}}=await c.auth.getUser();if(!user){router.push("/login");return;}const {error}=await c.from("trading_rules").upsert({user_id:user.id,max_trades_per_day:form.maxTrades,max_daily_loss_pct:form.maxLoss,risk_per_trade_pct:form.risk,max_consecutive_losses:form.maxLosses,preferred_session:form.session,personal_rules:form.rules.split("\n").map(x=>x.trim()).filter(Boolean)});if(error)alert(error.message);else router.push("/dashboard");setLoading(false);}
 const set=(k:string,v:string|number)=>setForm(f=>({...f,[k]:v}));
 return <main className="mx-auto min-h-screen max-w-2xl p-5 py-10"><div className="text-xl font-black">TradeGuard.</div><div className="mt-12"><div className="text-xs uppercase tracking-widest text-white/30">Step 1 of 1</div><h1 className="mt-3 text-4xl font-black">Set your trading rules.</h1><p className="mt-3 text-white/45">These rules power your personal discipline guardrails.</p></div><form onSubmit={submit} className="card mt-8 space-y-5 p-6">
 {[
  ["maxTrades","Maximum trades per day"],["maxLoss","Maximum daily loss (%)"],["risk","Risk per trade (%)"],["maxLosses","Maximum consecutive losses"]
 ].map(([k,l])=><label key={k} className="block text-sm">{l}<input className="input mt-2" type="number" min="1" step="0.1" value={(form as any)[k]} onChange={e=>set(k,Number(e.target.value))}/></label>)}
 <label className="block text-sm">Preferred trading session<select className="input mt-2" value={form.session} onChange={e=>set("session",e.target.value)}><option>London</option><option>New York</option><option>London/New York</option><option>Asian</option><option>Other</option></select></label>
 <label className="block text-sm">Personal rules <span className="text-white/30">(one per line)</span><textarea className="input mt-2 min-h-28" placeholder="Only trade my setup&#10;Never move my stop loss" value={form.rules} onChange={e=>set("rules",e.target.value)}/></label>
 <button disabled={loading} className="btn-primary w-full">{loading?"Saving...":"Enter TradeGuard"}</button>
 </form></main>
}