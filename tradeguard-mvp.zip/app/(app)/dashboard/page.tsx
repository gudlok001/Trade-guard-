 "use client";
import { useEffect,useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase-browser";
import type { Trade, TradingRules } from "@/lib/types";

export default function Dashboard(){
 const [trades,setTrades]=useState<Trade[]>([]); const [rules,setRules]=useState<TradingRules|null>(null); const [loading,setLoading]=useState(true);
 useEffect(()=>{(async()=>{const c=createClient();const {data:{user}}=await c.auth.getUser();if(!user)return;const [t,r]=await Promise.all([c.from("trades").select("*").eq("user_id",user.id).order("created_at",{ascending:false}),c.from("trading_rules").select("*").eq("user_id",user.id).maybeSingle()]);setTrades(t.data||[]);setRules(r.data);setLoading(false)})()},[]);
 const today=new Date().toISOString().slice(0,10); const todayTrades=trades.filter(t=>t.created_at.slice(0,10)===today); const pnl=todayTrades.reduce((s,t)=>s+Number(t.pnl||0),0); const losses=todayTrades.filter(t=>t.result==="Loss").length; const locked=!!rules&&(todayTrades.length>=rules.max_trades_per_day||losses>=rules.max_consecutive_losses);
 const discipline=todayTrades.length?Math.round(todayTrades.reduce((s,t)=>s+(t.followed_plan?100:35)-(t.revenge_trade?30:0)-(t.impulsive_trade?20:0),0)/todayTrades.length):100;
 if(loading)return <div className="py-20 text-white/40">Loading dashboard...</div>;
 return <div><div className="flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><div className="text-xs uppercase tracking-widest text-white/30">Today</div><h1 className="mt-2 text-4xl font-black">Your trading control room.</h1></div><Link href="/pre-trade" className="btn-primary">Run Pre-Trade Check</Link></div>
 <div className="mt-8 grid gap-4 md:grid-cols-4">{[
 ["Discipline",`${Math.max(0,Math.min(100,discipline))}/100`],["Trades",String(todayTrades.length)],["P/L",pnl>=0?`+${pnl}`:String(pnl)],["Status",locked?"LOCKED":"READY"]
 ].map(([a,b])=><div className="card p-5" key={a}><div className="text-xs text-white/40">{a}</div><div className="mt-3 text-2xl font-bold">{b}</div></div>)}</div>
 <div className={`mt-5 rounded-2xl border p-6 ${locked?"border-red-400/20 bg-red-400/5":"border-white/10 bg-white/[0.03]"}`}><div className="text-sm font-bold">{locked?"TRADING LOCKED":"READY TO TRADE"}</div><p className="mt-2 text-sm text-white/45">{locked?"A personal guardrail has been reached. Review your journal before taking another trade.":"Your current logged activity is within your configured guardrails. Always complete the Pre-Trade Gate before entering a trade."}</p></div>
 <div className="card mt-5 p-6"><div className="flex items-center justify-between"><h2 className="font-bold">Recent trades</h2><Link href="/journal" className="text-sm text-white/40 underline">View journal</Link></div>{trades.slice(0,5).map(t=><div key={t.id} className="flex items-center justify-between border-b border-white/5 py-4 last:border-0"><div><div className="font-semibold">{t.pair} · {t.direction}</div><div className="text-xs text-white/35">{new Date(t.created_at).toLocaleString()}</div></div><div className={t.pnl>=0?"text-white":"text-red-300"}>{t.pnl>=0?"+":""}{t.pnl}</div></div>)}{!trades.length&&<p className="py-10 text-center text-sm text-white/30">No trades logged yet.</p>}</div>
 </div>
}