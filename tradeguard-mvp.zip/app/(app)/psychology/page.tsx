 "use client";
import { useEffect,useState } from "react";
import { createClient } from "@/lib/supabase-browser";
import type { Trade } from "@/lib/types";

export default function Psychology(){
 const [t,setT]=useState<Trade[]>([]);useEffect(()=>{(async()=>{const c=createClient();const {data:{user}}=await c.auth.getUser();if(user){const {data}=await c.from("trades").select("*").eq("user_id",user.id);setT(data||[])}})()},[]);
 const total=t.length,wins=t.filter(x=>x.result==="Win").length,rev=t.filter(x=>x.revenge_trade).length,imp=t.filter(x=>x.impulsive_trade).length,follow=t.filter(x=>x.followed_plan).length,pnl=t.reduce((s,x)=>s+Number(x.pnl||0),0),wr=total?Math.round(wins/total*100):0,fp=total?Math.round(follow/total*100):0;
 const emotions=t.reduce<Record<string,number>>((a,x)=>{a[x.emotional_before]=(a[x.emotional_before]||0)+1;return a},{});const common=Object.entries(emotions).sort((a,b)=>b[1]-a[1])[0]?.[0]||"—";
 return <div><div className="text-xs uppercase tracking-widest text-white/30">Psychology</div><h1 className="mt-2 text-4xl font-black">Behavior over outcome.</h1><p className="mt-3 max-w-2xl text-white/45">Your performance numbers describe outcomes. These metrics describe the behaviors surrounding those outcomes.</p>
 <div className="mt-8 grid gap-4 md:grid-cols-4">{[["Trades",total],["Win rate",`${wr}%`],["P/L",pnl],["Rule-following",`${fp}%`],["Revenge trades",rev],["Impulsive trades",imp],["Common emotion",common],["Discipline",`${Math.max(0,Math.min(100,Math.round(fp-(rev/Math.max(1,total))*30-(imp/Math.max(1,total))*20)))} / 100`]].map(([a,b])=><div className="card p-5" key={a}><div className="text-xs text-white/40">{a}</div><div className="mt-3 text-2xl font-bold">{b}</div></div>)}</div>
 <div className="card mt-5 p-6"><h2 className="font-bold">Behavioral interpretation</h2><ul className="mt-4 space-y-3 text-sm leading-6 text-white/50"><li>• A winning trade can still violate your plan.</li><li>• A losing trade can still be a disciplined trade.</li><li>• These metrics are observations from your journal, not predictions of future performance.</li></ul></div></div>
}