 "use client";
import { useState } from "react";
import Link from "next/link";

const questions=["Am I following one of my planned setups?","Have I calculated my risk before entering?","Am I within my daily risk limit?","Am I trying to recover money from a previous loss?","Am I emotionally calm enough to trade?","Would I still take this trade if my previous trade had been a winner?","Have I already broken any trading rule today?"];

export default function PreTrade(){
 const [answers,setAnswers]=useState<(boolean|null)[]>(Array(7).fill(null)); const complete=answers.every(x=>x!==null); const danger=complete&&((answers[3]===true)||(answers[4]===false)||(answers[6]===true)); const yes=answers.filter(Boolean).length;
 return <div className="max-w-3xl"><div className="text-xs uppercase tracking-widest text-white/30">Pre-Trade Gate</div><h1 className="mt-2 text-4xl font-black">Pause before you enter.</h1><p className="mt-3 text-white/45">This check is designed to make your decision visible before you act.</p>
 <div className="card mt-8 divide-y divide-white/10">{questions.map((q,i)=><div key={q} className="p-5"><div className="text-sm leading-6">{q}</div><div className="mt-4 flex gap-2"><button onClick={()=>setAnswers(a=>a.map((v,j)=>j===i?true:v))} className={`btn-secondary ${answers[i]===true?"bg-white text-black":""}`}>Yes</button><button onClick={()=>setAnswers(a=>a.map((v,j)=>j===i?false:v))} className={`btn-secondary ${answers[i]===false?"bg-white text-black":""}`}>No</button></div></div>)}</div>
 {complete&&<div className={`mt-5 rounded-2xl border p-6 ${danger?"border-red-400/30 bg-red-400/5":"border-white/10 bg-white/[0.03]"}`}><div className="text-xl font-black">{danger?"PAUSE BEFORE TRADING":"CHECK COMPLETE"}</div><p className="mt-2 text-sm text-white/50">{danger?"Your answers contain signals that deserve a pause. Review your rules and journal before deciding what to do next.":"Your answers do not flag the specific guardrails monitored by this check. Continue to follow your trading plan and risk rules."}</p><div className="mt-4 text-xs text-white/35">{yes}/7 answers were “Yes”.</div></div>}
 <Link href="/journal" className="btn-primary mt-6 inline-block">Go to Journal</Link></div>
}