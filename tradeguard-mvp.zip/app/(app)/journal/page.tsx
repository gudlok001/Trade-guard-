 "use client";
import { FormEvent,useEffect,useState } from "react";
import { createClient } from "@/lib/supabase-browser";
import type { Trade } from "@/lib/types";

const initial={pair:"EUR/USD",direction:"Buy",entry:"",sl:"",tp:"",size:"",risk:"1",result:"Win",pnl:"",before:"Calm",after:"Calm",reason:"",followed:true,revenge:false,impulsive:false,notes:""};

export default function Journal(){
 const [f,setF]=useState(initial);const [trades,setTrades]=useState<Trade[]>([]);const [saving,setSaving]=useState(false);
 async function load(){const c=createClient();const {data:{user}}=await c.auth.getUser();if(!user)return;const {data}=await c.from("trades").select("*").eq("user_id",user.id).order("created_at",{ascending:false});setTrades(data||[])} useEffect(()=>{load()},[]);
 const set=(k:string,v:any)=>setF(x=>({...x,[k]:v}));
 async function submit(e:FormEvent){e.preventDefault();setSaving(true);const c=createClient();const {data:{user}}=await c.auth.getUser();if(!user)return;const {error}=await c.from("trades").insert({user_id:user.id,pair:f.pair,direction:f.direction,entry_price:Number(f.entry),stop_loss:f.sl?Number(f.sl):null,take_profit:f.tp?Number(f.tp):null,position_size:f.size?Number(f.size):null,risk_pct:Number(f.risk),result:f.result,pnl:Number(f.pnl||0),emotional_before:f.before,emotional_after:f.after,setup_reason:f.reason,followed_plan:f.followed,revenge_trade:f.revenge,impulsive_trade:f.impulsive,notes:f.notes});if(error)alert(error.message);else{setF(initial);load()}setSaving(false)}
 return <div><div className="text-xs uppercase tracking-widest text-white/30">Journal</div><h1 className="mt-2 text-4xl font-black">Log the decision, not just the result.</h1><form onSubmit={submit} className="card mt-8 grid gap-4 p-6 md:grid-cols-2">
 <label className="text-sm">Pair<input className="input mt-2" value={f.pair} onChange={e=>set("pair",e.target.value)}/></label><label className="text-sm">Direction<select className="input mt-2" value={f.direction} onChange={e=>set("direction",e.target.value)}><option>Buy</option><option>Sell</option></select></label>
 {[["entry","Entry price"],["sl","Stop-loss"],["tp","Take-profit"],["size","Position size"],["risk","Risk %"],["pnl","Profit/Loss"]].map(([k,l])=><label className="text-sm" key={k}>{l}<input className="input mt-2" type="number" step="any" value={(f as any)[k]} onChange={e=>set(k,e.target.value)} required={k==="entry"||k==="pnl"}/></label>)}
 <label className="text-sm">Result<select className="input mt-2" value={f.result} onChange={e=>set("result",e.target.value)}><option>Win</option><option>Loss</option><option>Breakeven</option></select></label>
 <label className="text-sm">Emotion before<select className="input mt-2" value={f.before} onChange={e=>set("before",e.target.value)}>{["Calm","Confident","Anxious","Fearful","Excited","Angry","FOMO"].map(x=><option key={x}>{x}</option>)}</select></label>
 <label className="text-sm md:col-span-2">Setup/reason<textarea className="input mt-2" value={f.reason} onChange={e=>set("reason",e.target.value)} placeholder="Why did you take this trade?"/></label>
 <div className="grid gap-3 text-sm md:col-span-2 md:grid-cols-3">{[["followed","I followed my plan"],["revenge","This was revenge trading"],["impulsive","This was impulsive"]].map(([k,l])=><label key={k} className="flex items-center gap-2 rounded-xl border border-white/10 p-3"><input type="checkbox" checked={(f as any)[k]} onChange={e=>set(k,e.target.checked)}/>{l}</label>)}</div>
 <label className="text-sm md:col-span-2">Notes<textarea className="input mt-2 min-h-24" value={f.notes} onChange={e=>set("notes",e.target.value)}/></label>
 <button disabled={saving} className="btn-primary md:col-span-2">{saving?"Saving...":"Save Trade"}</button></form>
 <div className="card mt-6 overflow-hidden"><div className="p-5 font-bold">Trade history</div>{trades.map(t=><div key={t.id} className="grid grid-cols-2 gap-3 border-t border-white/5 p-5 text-sm md:grid-cols-5"><span>{t.pair}</span><span>{t.direction}</span><span>{t.result}</span><span>{t.followed_plan?"Plan followed":"Rule broken"}</span><span className={t.pnl>=0?"":"text-red-300"}>{t.pnl>=0?"+":""}{t.pnl}</span></div>)}{!trades.length&&<div className="p-10 text-center text-sm text-white/30">Your journal is empty.</div>}</div></div>
}