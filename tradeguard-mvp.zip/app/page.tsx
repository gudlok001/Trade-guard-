import Link from "next/link";

export default function Home() {
  return <main className="min-h-screen">
    <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-6"><div className="text-xl font-black">TradeGuard.</div><Link href="/login" className="btn-secondary">Log in</Link></header>
    <section className="mx-auto max-w-5xl px-5 py-24 text-center md:py-32">
      <div className="mb-5 inline-block rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs text-white/60">Trading psychology & discipline</div>
      <h1 className="text-5xl font-black tracking-tight md:text-7xl">Trade your plan,<br/>not your emotions.</h1>
      <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-white/55">TradeGuard helps forex traders identify revenge trading, impulsive decisions, and rule-breaking before these behaviors become habits.</p>
      <div className="mt-9 flex justify-center gap-3"><Link href="/signup" className="btn-primary">Start Trading With Discipline</Link><Link href="/login" className="btn-secondary">Log in</Link></div>
    </section>
    <section className="mx-auto grid max-w-6xl gap-4 px-5 pb-24 md:grid-cols-3">
      {[
        ["01","Pre-Trade Gate","Pause and check your mindset before entering a trade."],
        ["02","Trade Journal","Track your decisions, emotions, rules and outcomes."],
        ["03","Psychology Analytics","See behavioral patterns in your own trading history."]
      ].map(x=><div className="card p-6" key={x[0]}><div className="text-xs text-white/30">{x[0]}</div><h2 className="mt-8 text-xl font-bold">{x[1]}</h2><p className="mt-3 text-sm leading-6 text-white/50">{x[2]}</p></div>)}
    </section>
    <footer className="border-t border-white/10 py-8 text-center text-xs text-white/30">TradeGuard is a journaling and behavioral-awareness tool. It does not provide financial advice, trading signals, or guarantees of trading performance.</footer>
  </main>;
}