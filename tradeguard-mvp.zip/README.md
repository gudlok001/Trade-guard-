# TradeGuard MVP

A mobile-first trading psychology and discipline journal built with Next.js, TypeScript, Tailwind and Supabase.

## Run locally

1. Install Node.js 20+.
2. Copy `.env.example` to `.env.local`.
3. Create a Supabase project.
4. In Supabase SQL Editor, run `supabase/schema.sql`.
5. Put your Supabase URL and anon key in `.env.local`.
6. Run:

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Supabase Auth

Enable Email/Password authentication in Supabase Authentication settings.

For production, configure your Supabase email templates and redirect URLs.

## Deploy

Push the project to GitHub and import it into Vercel. Add the two environment variables from `.env.local` to the Vercel project.

## Important

This MVP intentionally does not connect to a broker, execute trades, provide signals, or make financial predictions.

Before charging customers, add payment processing, stronger server-side authorization checks, account deletion/export, error monitoring, privacy/terms pages, and production testing.
