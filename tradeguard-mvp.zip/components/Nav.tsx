 "use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, ShieldCheck, BookOpen, Brain, CalendarCheck, Settings, LogOut } from "lucide-react";
import { createClient } from "@/lib/supabase-browser";

const links = [
  ["/dashboard", "Dashboard", LayoutDashboard],
  ["/pre-trade", "Pre-Trade", ShieldCheck],
  ["/journal", "Journal", BookOpen],
  ["/psychology", "Psychology", Brain],
  ["/weekly-review", "Weekly Review", CalendarCheck],
  ["/settings", "Settings", Settings]
] as const;

export default function Nav() {
  const pathname = usePathname();
  const router = useRouter();
  async function logout() {
    await createClient().auth.signOut();
    router.push("/login");
    router.refresh();
  }
  return <aside className="fixed inset-y-0 left-0 hidden w-64 border-r border-white/10 bg-[#090d15] p-5 md:block">
    <div className="mb-10"><div className="text-xl font-black">TradeGuard<span className="text-white/40">.</span></div><div className="mt-1 text-xs text-white/40">Trade your plan.</div></div>
    <nav className="space-y-1">
      {links.map(([href, label, Icon]) => <Link key={href} href={href} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm ${pathname === href ? "bg-white text-black" : "text-white/60 hover:bg-white/5 hover:text-white"}`}><Icon size={18}/>{label}</Link>)}
    </nav>
    <button onClick={logout} className="absolute bottom-6 flex items-center gap-3 px-3 text-sm text-white/40 hover:text-white"><LogOut size={18}/>Logout</button>
  </aside>
}