 "use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, ShieldCheck, BookOpen, Brain, Settings } from "lucide-react";

const links = [
  ["/dashboard", "Home", LayoutDashboard],
  ["/pre-trade", "Pre-Trade", ShieldCheck],
  ["/journal", "Journal", BookOpen],
  ["/psychology", "Psychology", Brain],
  ["/settings", "Settings", Settings]
] as const;

export default function MobileNav() {
  const pathname = usePathname();
  return <div className="fixed bottom-0 left-0 right-0 z-20 grid grid-cols-5 border-t border-white/10 bg-[#090d15] md:hidden">
    {links.map(([href, label, Icon]) => <Link key={href} href={href} className={`flex flex-col items-center gap-1 py-3 text-[10px] ${pathname === href ? "text-white" : "text-white/40"}`}><Icon size={18}/>{label}</Link>)}
  </div>
}