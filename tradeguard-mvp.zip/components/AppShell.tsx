import Nav from "./Nav";
import MobileNav from "./MobileNav";

export default function AppShell({ children }: { children: React.ReactNode }) {
  return <><Nav/><main className="min-h-screen pb-24 md:ml-64 md:pb-0"><div className="mx-auto max-w-6xl p-5 md:p-10">{children}</div></main><MobileNav/></>;
}