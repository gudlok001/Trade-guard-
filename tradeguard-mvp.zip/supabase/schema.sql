create extension if not exists "pgcrypto";

create table if not exists public.trading_rules (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade unique,
  max_trades_per_day integer not null default 3,
  max_daily_loss_pct numeric not null default 2,
  risk_per_trade_pct numeric not null default 1,
  max_consecutive_losses integer not null default 2,
  preferred_session text not null default 'London/New York',
  personal_rules text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.trades (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  pair text not null,
  direction text not null check (direction in ('Buy','Sell')),
  entry_price numeric not null,
  stop_loss numeric,
  take_profit numeric,
  position_size numeric,
  risk_pct numeric,
  result text not null check (result in ('Win','Loss','Breakeven')),
  pnl numeric not null default 0,
  emotional_before text not null default 'Calm',
  emotional_after text not null default 'Calm',
  setup_reason text not null default '',
  followed_plan boolean not null default true,
  revenge_trade boolean not null default false,
  impulsive_trade boolean not null default false,
  notes text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.pre_trade_assessments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  answers jsonb not null,
  danger boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.weekly_reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  week_start date not null,
  reflection text not null default '',
  created_at timestamptz not null default now()
);

alter table public.trading_rules enable row level security;
alter table public.trades enable row level security;
alter table public.pre_trade_assessments enable row level security;
alter table public.weekly_reviews enable row level security;

create policy "users manage own rules" on public.trading_rules for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "users manage own trades" on public.trades for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "users manage own assessments" on public.pre_trade_assessments for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "users manage own reviews" on public.weekly_reviews for all using (auth.uid()=user_id) with check (auth.uid()=user_id);