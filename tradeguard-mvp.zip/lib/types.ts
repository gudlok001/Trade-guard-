export type TradingRules = {
  id?: string;
  user_id?: string;
  max_trades_per_day: number;
  max_daily_loss_pct: number;
  risk_per_trade_pct: number;
  max_consecutive_losses: number;
  preferred_session: string;
  personal_rules: string[];
};

export type Trade = {
  id: string;
  pair: string;
  direction: "Buy" | "Sell";
  entry_price: number;
  stop_loss: number | null;
  take_profit: number | null;
  position_size: number | null;
  risk_pct: number | null;
  result: "Win" | "Loss" | "Breakeven";
  pnl: number;
  emotional_before: string;
  emotional_after: string;
  setup_reason: string;
  followed_plan: boolean;
  revenge_trade: boolean;
  impulsive_trade: boolean;
  notes: string;
  created_at: string;
};